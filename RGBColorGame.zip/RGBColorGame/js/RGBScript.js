var color = new Array();
var box = new Array();
var row = new Array();
function genColors(){
    if(row.length == 2){
        for(var j=0;j<6;j++){
            for(var i=0;i<3;i++){
                color[i] = Math.floor(Math.random()*256);
            }
            box[j].style.backgroundColor = "rgb("+color[0]+","+color[1]+","+color[2]+")";
        }
        document.getElementsByClassName("colorGuess")[0].innerHTML=box[Math.floor(Math.random()*6)].style.backgroundColor;
        document.getElementsByTagName('header')[0].style.backgroundColor = "#22b3ec";
        document.getElementById('success').innerHTML="";
    }

    else{
        for(var j=0;j<3;j++){
            for(var i=0;i<3;i++){
                color[i] = Math.floor(Math.random()*256);
            }
            box[j].style.backgroundColor = "rgb("+color[0]+","+color[1]+","+color[2]+")";
        }
        document.getElementsByClassName("colorGuess")[0].innerHTML=box[Math.floor(Math.random()*3)].style.backgroundColor;
        document.getElementsByTagName('header')[0].style.backgroundColor = "#22b3ec";
        document.getElementById('success').innerHTML="";
    }
    return box;
}
function genGrid1x3(){
    row = new Array();
    box = new Array();
    document.getElementsByClassName("colorGrid")[0].innerHTML="";
    row[0] = document.createElement('tr');
    for(var i = 0; i<3;i++){
        box[i] = document.createElement('td');
    }
    for(var j=0; j<3;j++){
        row[0].appendChild(box[j]);
    }
    document.getElementsByClassName("colorGrid")[0].appendChild(row[0]);
    genColors();
    for(var m =0; m<3;m++){
        box[m].addEventListener("click", function() {
            if(this.style.backgroundColor == document.getElementsByClassName('colorGuess')[0].innerHTML){
                for(var n = 0; n<3;n++){
                    box[n].style.backgroundColor= this.style.backgroundColor;
                    document.getElementsByTagName('header')[0].style.backgroundColor = this.style.backgroundColor;
                }
                document.getElementById('success').innerHTML="You're Right!!";
            }
            else {
                this.removeEventListener("click",function(){
                    if(this.style.backgroundColor == document.getElementsByClassName('colorGuess')[0].innerHTML){
                        for(var n = 0; n<6;n++){
                            box[n].style.backgroundColor= this.style.backgroundColor;
                            document.getElementsByTagName('header')[0].style.backgroundColor = this.style.backgroundColor;
                        }
                        document.getElementById('success').innerHTML="You're Right!!";
                    }
                });
                this.style.backgroundColor="inherit";
            }
        });
    }

}
function genGrid2x3(){
    row = new Array();
    box = new Array();
    document.getElementsByClassName("colorGrid")[0].innerHTML="";
    for(var i = 0; i<6;i++){
        box[i] = document.createElement('td');
    }
    for(var l=0; l<2;l++){
        row[l] = document.createElement('tr');
    }
    for(var j=0; j<3;j++){
        row[0].appendChild(box[j]);
    }
    for(var j=3; j<6;j++){
        row[1].appendChild(box[j]);
    }
    document.getElementsByClassName("colorGrid")[0].appendChild(row[0]);
    document.getElementsByClassName("colorGrid")[0].appendChild(row[1]);
    genColors();
    for(var m =0; m<6;m++){
        box[m].addEventListener("click", function() {
            console.log("You clicked me");
            if(this.style.backgroundColor == document.getElementsByClassName('colorGuess')[0].innerHTML){
                for(var n = 0; n<6;n++){
                    box[n].style.backgroundColor= this.style.backgroundColor;
                    document.getElementsByTagName('header')[0].style.backgroundColor = this.style.backgroundColor;
                }
                document.getElementById('success').innerHTML="You're Right!!";
            }
            else {
                this.removeEventListener("click",function(){
                    console.log("You clicked me");
                    if(this.style.backgroundColor == document.getElementsByClassName('colorGuess')[0].innerHTML){
                        for(var n = 0; n<6;n++){
                            box[n].style.backgroundColor= this.style.backgroundColor;
                            document.getElementsByTagName('header')[0].style.backgroundColor = this.style.backgroundColor;
                        }
                        document.getElementById('success').innerHTML="You're Right!!";
                    }
                });
                this.style.backgroundColor="inherit";
            }
        });
    }

}
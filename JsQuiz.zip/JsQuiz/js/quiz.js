var questions = ["What is 2+2", "What is 2x2", "What is 3-2"];
var answersA = ["1", "3", "2"];
var answersB = ["4","5","8"];
var answersC = ["7", "4","3"];
var answersD = ["2", "8", "1"];
var correct = [answersB,answersC,answersD];
var j=0;
function dispQuestion(x){
    document.getElementById("response").innerHTML = "";
    document.getElementById("answerA").style.backgroundColor="#ffae009c";
    document.getElementById("answerB").style.backgroundColor="#ffae009c";
    document.getElementById("answerC").style.backgroundColor="#ffae009c";
    document.getElementById("answerD").style.backgroundColor="#ffae009c";
    document.getElementById("question").innerHTML = questions[x];
    document.getElementById("answerA").innerHTML = "A. " +answersA[x];
    document.getElementById("answerA").addEventListener("click", function(){
        clicked(x, this);
    });
    document.getElementById("answerB").innerHTML = "B. " +answersB[x];
    document.getElementById("answerB").addEventListener("click", function(){
        clicked(x, this);
    });
    document.getElementById("answerC").innerHTML = "C. " +answersC[x];
    document.getElementById("answerC").addEventListener("click", function(){
        clicked(x, this);
    });
    document.getElementById("answerD").innerHTML = "D. " +answersD[x];
    document.getElementById("answerD").addEventListener("click", function(){
        clicked(x, this);
    });
    j++
    if(j == questions.length){
        j=0;
    }
}
function clicked(x, obj){
    console.log(obj.style.backgroundColor);
    console.log(obj.innerHTML.split(" ")[1]);
    if(obj.innerHTML.split(" ")[1] == correct[x][x]){
        document.getElementById("response").innerHTML = "You are correct";
        obj.style.backgroundColor="green";
    }
    else{
        document.getElementById("response").innerHTML = "That is incorrect try again";
        obj.style.backgroundColor = "#FF0000";
    }
}
function next(){
    dispQuestion(j);
}